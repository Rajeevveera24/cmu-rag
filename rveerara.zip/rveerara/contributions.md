Data Annotation Contributions
- All annotations were created manually by Rajeev Veeraraghavan
Data Collection 
- Sudeep Agarwal (sudeepag@andreew.cmu.edu) - ontributed to the scraping of raw data for academic calendar schedule, LTI faculty and LTI faculty research
- Hugo C (hcontant@andrw.cmu.edu) - contributed to the scraping of raw data for Kiltie band, Scottie and Tartans
Data Processing
 -  All data processing was done by Rajeev Veeraraghavan
Model Contributions
 - All models were created and tested by Rajeev Veeraraghavan